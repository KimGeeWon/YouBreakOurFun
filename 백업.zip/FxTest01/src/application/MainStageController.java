package application;

import com.dgsw.tcpcom.TcpClient;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class MainStageController
{
	@FXML
	private Button btn1;
	@FXML
	private Button btn2;
	@FXML
	private Button btn3;
	@FXML
	private Button btn4;
	@FXML
	private Button btn5;
	@FXML
	private Button btn6;
	@FXML
	private Button btn7;
	@FXML
	private Button btn8;
	@FXML
	private Label Label1;
	@FXML
	private TextField lineValue1;
	@FXML
	private TextField lineValue2;
	@FXML
	private TextField lineValue3;
	@FXML
	private TextField lineValue4;
	
	public MainStageController()
	{
		super();
	}
	@FXML
	private void initialize()
	{
		btn1.setText("button1");
		btn1.setOnAction(new EventHandler<ActionEvent>()
		{
			@Override
			public void handle(ActionEvent event)
			{
				System.out.println("button1");
//				TcpClient client = new TcpClient("10.80.163.159", 5200);
//				client.ClientRun("A\n");
			}
		});
		Label1.setText("test");
		Label1.setOnMousePressed(new EventHandler<MouseEvent>()
		{
			@Override
			public void handle(MouseEvent event)
			{
				System.out.println("x : " + event.getX());
				System.out.println("y : " + event.getY());
				System.out.println("line1 : " + lineValue1.getText());
				System.out.println("line2 : " + lineValue2.getText());
				
				String sendFormat = "%s_%s_%s_%s";
				String sendData = String.format(sendFormat,
						lineValue1.getText(),
						lineValue2.getText(),
						event.getX()+"",
						event.getY()+""
						);
				
				System.out.println(sendData);
				String[] rev = sendData.split("_");
				if(rev != null && rev.length==4)
				{
					System.out.println("x2 : " + rev[2]);
					System.out.println("y2 : " + rev[3]);
					System.out.println("line1 : " + rev[0]);
					System.out.println("line2 : " + rev[1]);
				}
			}
		});
	}
}
