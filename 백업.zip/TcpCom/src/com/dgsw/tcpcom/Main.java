package com.dgsw.tcpcom;

import java.io.IOException;
import java.io.File;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;

import com.dgsw.tcpcom.constant.Contants;

public class Main
{
	public void abc(String code)
	{
		File bgm;
		AudioInputStream stream;
		AudioFormat format;
		DataLine.Info info;

//		bgm = new File(
//				"C:\\Users\\김지원\\Desktop\\너흥다깨\\기타\\ACFree\\AcousticGuitarFREE\\AcousticGuitarFREE Samples/A_Fin_L1B_16.wav");
		
		if(code ==null)
			return;
		
		bgm = new File(code);
		Clip clip;

		try
		{
			stream = AudioSystem.getAudioInputStream(bgm);
			format = stream.getFormat();
			info = new DataLine.Info(Clip.class, format);
			clip = (Clip) AudioSystem.getLine(info);
			clip.open(stream);
			clip.start();
		} 
		catch (Exception e)
		{
			System.out.println("err : " + e);
		}
	}
	
	public static void main(String[] args)
	{
		TcpServer server =  new TcpServer();
		
		try
		{
			server.ServerRun();
		} 
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
//		TcpClient client = new TcpClient("10.80.163.85", 5300);
//		client.ClientRun("TEST");
	}
}