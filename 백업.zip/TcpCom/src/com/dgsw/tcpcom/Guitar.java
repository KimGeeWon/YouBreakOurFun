package com.dgsw.tcpcom;

import com.dgsw.tcpcom.constant.Contants;

public class Guitar
{

	//	x2 rev[1]							x800 y480
	//	y2 rev[2]
	//	line1 rev[0]
	
	final int STRING = 100;
	final int STRING3 = STRING / 3;
	final int XMAX = 800;
	final int YMAX = 200;
	final int SOUND_SIZE = Contants.SOUND_FOOL.length;

//	public int getLocation(int value)
//	{
//		int result = 0;
//		int standard = (XMAX * YMAX) / SOUND_SIZE;
//		int i = 1;
//		do
//		{
//			if (value < (standard * i))
//			{
//				result = i;
//				break;
//			}
//			i++;
//		} while ((standard * i) < (XMAX * YMAX));
//		if (result > SOUND_SIZE)
//			result = 0;
//		
//		return result;
//	}
	
	public int getString(String rev[])
	{
		int line = (int) Double.parseDouble(rev[0]);
		int result=0;
		
		if(line <= STRING)
			result = 18;
		if(line < STRING - STRING3)
			result = 9;
		if(line < STRING - 2*STRING3)
			result = 0;
		
		return result;
	}
	
	public int getLocation(int x, int y, int line)
	{
		int result = -1 + line;
		for(int i=0; i<8; i++) {
			double pos = getMatrix(x,i);
			if(pos>y) {
				result = i + line;
				break;
			}
		}
		if(result == -1 + line) {
			result = 8 + line;
		}
		System.out.println(result);
		
		return result;
	}
	
	private double getMatrix(int x, int num) {
		return -0.3125 * x + 50 * (num+1);
	}

	public String translate(String data)
	{
		System.out.println(data);
		
		String[] rev = data.split("_"); // x y 좌표, 줄 1

		int xLoc = (int) Double.parseDouble(rev[1]);
		int yLoc = (int) Double.parseDouble(rev[2]);
		
		int result = getString(rev);
		
		if (getLocation(xLoc, yLoc, result) != -1)
			return Contants.SOUND_FOOL[getLocation(xLoc, yLoc, result)];
		else
			return null;

	}
}
