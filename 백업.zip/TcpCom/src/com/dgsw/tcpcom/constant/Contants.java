package com.dgsw.tcpcom.constant;

public class Contants
{
	public static final String PATH = "C:\\Users\\김지원\\Desktop\\너흥다깨\\기타\\ACFree\\AcousticGuitarFREE\\AcousticGuitarFREE Samples\\";
	public static final String MIDDLE = "A_Fin_L1A_";
	public static final String A_Fin_L1A_01 = PATH + MIDDLE + "01.wav";
	public static final String A_Fin_L1A_02 = PATH + MIDDLE + "02.wav";
	public static final String A_Fin_L1A_03 = PATH + MIDDLE + "03.wav";
	public static final String A_Fin_L1A_04 = PATH + MIDDLE + "04.wav";
	public static final String A_Fin_L1A_05 = PATH + MIDDLE + "05.wav";
	public static final String A_Fin_L1A_06 = PATH + MIDDLE + "06.wav";
	public static final String A_Fin_L1A_07 = PATH + MIDDLE + "07.wav";
	public static final String A_Fin_L1A_08 = PATH + MIDDLE + "08.wav";
	public static final String A_Fin_L1A_09 = PATH + MIDDLE + "09.wav";
	public static final String A_Fin_L1A_10 = PATH + MIDDLE + "10.wav";
	public static final String A_Fin_L1A_11 = PATH + MIDDLE + "11.wav";
	public static final String A_Fin_L1A_12 = PATH + MIDDLE + "12.wav";
	public static final String A_Fin_L1A_13 = PATH + MIDDLE + "13.wav";
	public static final String A_Fin_L1A_14 = PATH + MIDDLE + "14.wav";
	public static final String A_Fin_L1A_15 = PATH + MIDDLE + "15.wav";
	public static final String A_Fin_L1A_16 = PATH + MIDDLE + "16.wav";
	public static final String A_Fin_L1A_17 = PATH + MIDDLE + "17.wav";
	public static final String A_Fin_L1A_18 = PATH + MIDDLE + "18.wav";
	public static final String A_Fin_L1A_19 = PATH + MIDDLE + "19.wav";
	public static final String A_Fin_L1A_20 = PATH + MIDDLE + "20.wav";
	public static final String A_Fin_L1A_21 = PATH + MIDDLE + "21.wav";
	public static final String A_Fin_L1A_22 = PATH + MIDDLE + "22.wav";
	public static final String A_Fin_L1A_23 = PATH + MIDDLE + "23.wav";
	public static final String A_Fin_L1A_24 = PATH + MIDDLE + "24.wav";
	public static final String A_Fin_L1A_25 = PATH + MIDDLE + "25.wav";
	public static final String A_Fin_L1A_26 = PATH + MIDDLE + "26.wav";
	
	public static final String[] SOUND_FOOL = new String[] {
			A_Fin_L1A_01,
			A_Fin_L1A_02,
			A_Fin_L1A_03,
			A_Fin_L1A_04,
			A_Fin_L1A_05,
			A_Fin_L1A_06,
			A_Fin_L1A_07,
			A_Fin_L1A_08,
			A_Fin_L1A_09,
			A_Fin_L1A_10,
			A_Fin_L1A_11,
			A_Fin_L1A_12,
			A_Fin_L1A_13,
			A_Fin_L1A_14,
			A_Fin_L1A_15,
			A_Fin_L1A_16,
			A_Fin_L1A_17,
			A_Fin_L1A_18,
			A_Fin_L1A_19,
			A_Fin_L1A_20,
			A_Fin_L1A_21,
			A_Fin_L1A_22,
			A_Fin_L1A_23,
			A_Fin_L1A_24,
			A_Fin_L1A_25,
			A_Fin_L1A_26,
			A_Fin_L1A_26
	}
	;

}
